# Sentiment Analysis Tool

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import string

# Step 1: Labeled Text Dataset

texts = [
    "I love this product",
    "This is amazing",
    "Very happy with the service",
    "Absolutely fantastic experience",
    "I am satisfied",
    "I hate this product",
    "This is terrible",
    "Worst experience ever",
    "Very disappointing service",
    "Not good at all"
]

labels = [
    "positive", "positive", "positive", "positive", "positive",
    "negative", "negative", "negative", "negative", "negative"
]
# Step 2: Text Preprocessing

def preprocess(text):
    text = text.lower()
    text = text.translate(str.maketrans("", "", string.punctuation))
    return text

texts = [preprocess(t) for t in texts]

# Step 3: Feature Extraction (TF-IDF)

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(texts)


# Step 4: Train-Test Split

X_train, X_test, y_train, y_test = train_test_split(
    X, labels, test_size=0.2, random_state=42
)


# Step 5: Train Classifier (Naive Bayes)
model = MultinomialNB()
model.fit(X_train, y_train)

# Step 6: Model Evaluation

y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

print("Model Accuracy:", accuracy)


# Step 7: User Input Prediction

print("\nEnter a sentence to analyze sentiment")
user_input = input("Text: ")

user_input_clean = preprocess(user_input)
user_vector = vectorizer.transform([user_input_clean])
prediction = model.predict(user_vector)

print("Predicted Sentiment:", prediction[0])
