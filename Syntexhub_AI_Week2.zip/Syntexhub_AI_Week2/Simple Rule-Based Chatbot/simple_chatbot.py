# Simple Rule-Based Chatbot

# Knowledge Base
knowledge_base = {
    "what is ai": "Artificial Intelligence is the ability of machines to think like humans.",
    "what is machine learning": "Machine Learning is a subset of AI that learns from data.",
    "what is chatbot": "A chatbot is a program that can chat with users like a human."
}

# Conversation History
chat_history = []

print(" Chatbot: Hello! I am a simple rule-based chatbot.")
print(" Chatbot: You can ask me about AI, Machine Learning, or Chatbots.")
print(" Chatbot: Type 'bye' to exit.\n")

while True:
    user_input = input("You: ").lower()
    chat_history.append("You: " + user_input)

    # Exit Intent
    if user_input in ["bye", "exit", "quit"]:
        reply = "Goodbye! Have a great day "
        print(" Chatbot:", reply)
        chat_history.append("Bot: " + reply)
        break

    # Greeting Intent
    elif any(word in user_input for word in ["hi", "hello", "hey"]):
        reply = "Hello! How can I help you?"

    # Help Intent
    elif "help" in user_input:
        reply = "I can answer questions about AI, Machine Learning, and Chatbots."

    # Small Talk Intent
    elif "how are you" in user_input:
        reply = "I'm fine! Thanks for asking "

    # Knowledge Base
    elif user_input in knowledge_base:
        reply = knowledge_base[user_input]

    # Default Response
    else:
        reply = "Sorry, I didn't understand that. Please try again."

    print(" Chatbot:", reply)
    chat_history.append("Bot: " + reply)

# Display Conversation History
print("\n--- Conversation History ---")
for chat in chat_history:
    print(chat)
